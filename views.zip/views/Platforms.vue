<template>
<PlatformUpPage/>
<PlatformFooter/>
</template>

<script setup>

import PlatformFooter from '@/components/Platforms/PlatformFooter.vue';
import PlatformUpPage from '@/components/Platforms/PlatformUpPage.vue';

</script>