<template>
<ArticleUpPage/>
<ArticleMidPage/>
<ArticleDownPage/>
<ArticleFooter/>
</template>

<script setup>

import ArticleDownPage from '@/components/Articles/ArticleDownPage.vue';
import ArticleFooter from '@/components/Articles/ArticleFooter.vue';
import ArticleMidPage from '@/components/Articles/ArticleMidPage.vue';
import ArticleUpPage from '@/components/Articles/ArticleUpPage.vue';

</script>