<template>
  <div class="signup-page">

    <div class="layer"></div>

    <div class="signup-wrapper">

        <div class="signup-box">

        <h2>SignUp</h2>

        <p class="subtitle">Welcome back to lessons</p>

        <form @submit.prevent="handleSubmit">

            <div class="input-group">

            <label for="fullname">Full Name</label>

            <input type="text" id="fullname" name="fullname" placeholder="Full Name" v-model="formData.fullname"/>

            </div>

            <div class="input-group">

            <label for="username">Username</label>

            <input type="text" id="username" name="username" placeholder="Username" v-model="formData.username"/>

            </div>

            <div class="input-group">

            <label for="email">E-mail</label>

            <input type="email" id="email" name="email" placeholder="E-Mail" v-model="formData.email"/>

            </div>

            <div class="input-group">

            <label for="password">Password</label>

            <input type="password" id="password" name="password" placeholder="Password" v-model="formData.password"/>

            </div>

            <p class="info-text">

              By signing up, you agree to our 
              <a href="#">Terms</a>, 
              <a href="#">Privacy Policy</a> and 
              <a href="#">Cookies Policy</a>.

            </p>

            <button type="submit" class="login-btn">SignUp</button>

            <p class="Login">
              
            Already have an account? <a href="http://localhost:5173/login">Log in into your account</a>

            </p>

        </form>

        </div>

    </div>

  </div>

</template>


<script setup>

import { ref } from 'vue'

const formData = ref({
  fullname: '',
  username: '',
  email: '',
  password: ''
})

const handleSubmit = (e) => {
    e.preventDefault();

    console.log(formData.value);
    
}

</script>


<style scoped>

.signup-page {
  min-height: 150vh;
  width: 100%;
  background-image: url('@/assets/login.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;

  display: flex;
  flex-direction: column;
  align-items: center;
}

.layer {
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3);
  flex-shrink: 0;
}

.signup-wrapper {
  width: 100%;
  display: flex;
  justify-content: center;
  padding: 120px 20px 60px;
  box-sizing: border-box;
  flex-grow: 1;
}

.signup-box {
  background: rgba(255, 255, 255, 0.95);
  padding: 2rem;
  border-radius: 15px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
  width: 350px;
  text-align: center;
  margin-top: 10px;
  margin-bottom: 40px;
}

.signup-box h2 {
  margin-bottom: 0.5rem;
  color: #5a3ec8;
}

.subtitle {
  color: #666;
  margin-bottom: 1.5rem;
}

.input-group {
  text-align: left;
  margin-bottom: 1rem;
}

.input-group label {
  display: block;
  margin-bottom: 5px;
  font-size: 0.9rem;
  color: #333;
}

.input-group input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  outline: none;
  font-size: 0.9rem;
  box-sizing: border-box;
}

.input-group input:focus {
  border-color: #5a3ec8;
}

.login-btn {
  width: 100%;
  padding: 12px;
  background: linear-gradient(to right, #6a5acd, #836fff);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 1rem;
  transition: transform 0.2s ease;
}

.login-btn:hover {
  transform: scale(1.05);
}

.Login {
  font-size: 0.9rem;
}

.Login a {
  color: #5a3ec8;
  text-decoration: none;
  font-weight: bold;
}

.Login a:hover {
  text-decoration: underline;
}

.info-text {
  font-size: 0.75rem;
  color: #555;
  text-align: center;
  margin: 1rem 0;
  line-height: 1.4;
}

.info-text a {
  color: #5a3ec8;
  text-decoration: none;
  font-weight: 500;
}

.info-text a:hover {
  text-decoration: underline;
}

</style>

