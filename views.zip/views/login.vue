<template>
  <div class="login-page">

    <div class="layer"></div>

    <div class="login-wrapper">
      
        <div class="login-box">

        <h2>Login</h2>

        <p class="subtitle">Welcome back to lessons</p>

        <form :onSubmit="handleSubmit">

            <div class="input-group">

            <label for="email">E-mail</label>

            <input type="email" id="email" name="email" placeholder="Enter your email" v-model="formData.email"/>

            </div>

            <div class="input-group">

            <label for="password">Password</label>

            <input type="password" id="password" name="password" placeholder="Password" v-model="formData.password"/>

            </div>

            <a href="#" class="forgot">I forgot my password</a>

            <button type="submit" class="login-btn">Login</button>

            <p class="signup">

            Don't have an account? <a href="http://localhost:5173/signup">Create an account</a>

            </p>

        </form>

        </div>

    </div>

  </div>

</template>

<style scoped>

.login-page {
  width: 100%;
  height: calc(100vh - 59px);
  background-image: url('@/assets/login.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;

  display: flex;
  flex-direction: column;
  align-items: center;
  overflow-y: auto;
}

.layer {
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.3);
  flex-shrink: 0;
}

.login-wrapper {
  width: 100%;
  display: flex;
  justify-content: center;
  box-sizing: border-box;
  flex-grow: 1;
}

.login-box {
  background: rgba(255, 255, 255, 0.95);
  padding: 2rem;
  border-radius: 15px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
  width: 350px;
  text-align: center;
  margin-top: -20px;
}

.login-box h2 {
  margin-bottom: 0.5rem;
  color: #5a3ec8;
}

.subtitle {
  color: #666;
  margin-bottom: 1.5rem;
}

.input-group {
  text-align: left;
  margin-bottom: 1rem;
}

.input-group label {
  display: block;
  margin-bottom: 5px;
  font-size: 0.9rem;
  color: #333;
}

.input-group input {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 8px;
  outline: none;
  font-size: 0.9rem;
  box-sizing: border-box;
}

.input-group input:focus {
  border-color: #5a3ec8;
}

.forgot {
  display: block;
  text-align: right;
  margin-bottom: 1rem;
  font-size: 0.85rem;
  color: #5a3ec8;
  text-decoration: none;
}

.forgot:hover {
  text-decoration: underline;
}

.login-btn {
  width: 100%;
  padding: 12px;
  background: linear-gradient(to right, #6a5acd, #836fff);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 1rem;
  cursor: pointer;
  margin-bottom: 1rem;
  transition: transform 0.2s ease;
}

.login-btn:hover {
  transform: scale(1.05);
}

.signup {
  font-size: 0.9rem;
}

.signup a {
  color: #5a3ec8;
  text-decoration: none;
  font-weight: bold;
}

.signup a:hover {
  text-decoration: underline;
}

.nav-to-home {
  font-size: 1.25rem;
  color: white;
  transition: color 0.3s ease;
}

.nav-to-home:hover {
  color: #FFD700;
}

.iconR {
  font-size: 5rem;
  color: white;
  margin: 20px auto 0 auto;
  display: flex;
  justify-content: center;
  transition: transform 0.3s ease, color 0.3s ease;
}

.iconR:hover {
  transform: scale(1.2);
}

.iconL {
  font-size: 1.25rem;
  color: white;
  margin: 40px 0 0 55px;
  transition: color 0.3s ease;
}

.iconL:hover {
  opacity: 0.5;
}

</style>

<script setup>

import { ref } from 'vue';


const formData = ref({
    email:'',
    password:'',
})

const handleSubmit = ()=>{
    console.log(
        formData.value
    );
    
}

</script>
