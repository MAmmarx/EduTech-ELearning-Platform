<template>
<HomeIntro/>
<Freelessons/>
<StartFreeTrial/>
<HomeSubscription/>
<HomeStatistics/>
<HomeFeatures/>
<HomeProductivity/>
<HomeHowToWork/>
</template>

<script setup>
import {HomeIntro, Freelessons} from '@/components';
import HomeFeatures from '@/components/home/HomeFeatures.vue';
import HomeHowToWork from '@/components/home/HomeHowToWork.vue';
import HomeProductivity from '@/components/home/HomeProductivity.vue';
import HomeStatistics from '@/components/home/HomeStatistics.vue';
import HomeSubscription from '@/components/home/HomeSubscription.vue';
import StartFreeTrial from '@/components/home/StartFreeTrial.vue';

</script>