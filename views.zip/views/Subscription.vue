<template>

<SubscriptionUpPage/>
<SubscriptionFooter/>

</template>

<script setup>
import SubscriptionFooter from '@/components/Subscription/SubscriptionFooter.vue';
import SubscriptionUpPage from '@/components/Subscription/SubscriptionUpPage.vue';
</script>