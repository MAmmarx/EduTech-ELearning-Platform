<template>
<VirtualSemester/>
<LearningManagementSystem/>
<FreeTrial/>
<FeaturesFooter/>
</template>

<script setup>

import FeaturesFooter from '@/components/Features/FeaturesFooter.vue';
import FreeTrial from '@/components/Features/FreeTrial.vue';
import LearningManagementSystem from '@/components/Features/LearningManagementSystem.vue';
import VirtualSemester from '@/components/Features/VirtualSemester.vue';

</script>