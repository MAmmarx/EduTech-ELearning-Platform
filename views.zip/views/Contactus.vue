<template>
<TeamInfo/>
<Form/>
<Footer/>
</template>

<script setup>

import TeamInfo from '@/components/ContactUs/TeamInfo.vue';
import Form from '@/components/ContactUs/Form.vue';
import Footer from '@/components/ContactUs/Footer.vue';


</script>